package com.zybooks.inventorytracker;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class RegistrationActivity extends AppCompatActivity {

    EditText userFName, userLName, userName, userRole, userPassword, userPasswordConf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        userName = findViewById(R.id.editTextUserName);
        userFName = findViewById(R.id.editTextFirstName);
        userLName = findViewById(R.id.editTextLastName);
        userPassword = findViewById(R.id.editTextPassword);
        userRole = findViewById(R.id.editTextRole);
        userPasswordConf = findViewById(R.id.editTextPasswordConf);

        Button buttonSubmit = (Button)findViewById(R.id.buttonSubmit);

        buttonSubmit.setOnClickListener(listener -> UserDatabase.getInstance(getApplicationContext())
                .addUser(userName.getText().toString().trim(),
                        userFName.getText().toString().trim(),
                        userLName.getText().toString().trim(),
                        userPassword.getText().toString().trim(),
                        userRole.getText().toString().trim()));
    }
}